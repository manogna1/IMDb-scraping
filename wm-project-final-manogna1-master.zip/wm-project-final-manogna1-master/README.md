# Web Scrape IMDb Website

### _**Question**_:
##### Find which country has produced top-rated movies and in which language and which decade highest top-rated movies are released using imDb website?

### _**Introduction**_:
To answer this question, we need to webscrape IMDb website to collect data because IMDb API's are not available.

### _**Procedure**_:
- Webscrape the IMDb top 250 rated page and collect movie names and movie links store them in respective lists.
- Collect the data of all the movies by using movielinks to webscrape all movie pages and store the data in respective lists.
- Create a dataframe using all collected data using pandas and pickle the dataframe to snapshot the work.
- Clean the data, language and country columns needs to cleaned.
- Visualize the collected data and analyze the results.

### _**Sources**_:
- Spyder
- Language: Python 3.0
- Modules required:
  BeautifulSoup, urllib, Pandas, Numpy, Seaborn, Matplotlib

### _**Visualization**_:
Visualize all the data collected to find results. Decade vs Number of top rated movies, Number of top rated movies vs Language, Number of top rated movies vs Country.
From visualization we can answer the question.

